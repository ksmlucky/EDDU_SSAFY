-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: localhost    Database: ssafy_web_db
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `quiz`
--

LOCK TABLES `quiz` WRITE;
/*!40000 ALTER TABLE `quiz` DISABLE KEYS */;
INSERT INTO `quiz` VALUES (7,'ㅇㄹ','ㄴㅇㅎㄴㅇ',0,'','',10,'choice',5),(103,'1','다음 그림의 이름은?',3,'케이크|모니터|마우스','be353396-71f4-448c-9169-749a54248612_cake.png',10,'choice',102),(361,'2','다음 문제를 푸세요',0,'','5a4dcd35-a36d-469a-9303-749a54ec843e_캡처.PNG',20,'choice',359),(430,'3','ucc 제목은?',3,'7기|싸피|공통_1반_C111',NULL,10,'choice',429),(467,'하현서','무슨 글자일까요?',3,'하현서|상현서|하현동','06ec3146-86a2-4e3a-9de0-549405705397_서명.png',1,'choice',466),(477,'1','피카츄의 진화는?',3,'라이츄|꼬부기|파이리','42e47563-2a55-4ef5-9e15-4d549e522772_EDDUSSAFY_얼굴만_동그라미.png',10,'choice',102),(478,'1','다음 그림의 이름은?',3,'나무집|벽돌집|아파트','641b5b7c-2e09-423f-b4c4-d33872f097f7_cabin.png',10,'choice',102),(479,'리자드','파이리의 진화는?',0,'',NULL,10,'subjective',102),(480,'SSAFY','싸피의 영어 스펠링은(대문자)?',0,'',NULL,10,'subjective',102),(482,'1','라이츄의 진화는?',3,'없음|피카츄|라이츄','4131a744-7df9-4102-b7ff-94449d12486d_EDDUSSAFY_얼굴만.png',10,'choice',102),(496,'라이츄','피카츄의 진화는?',0,'',NULL,10,'subjective',495),(563,'EDDU SSAFY','현재 접속해 있는 이 서비스의 이름은?(모두 대문자로)',0,'',NULL,20,'subjective',27),(564,'1','피카츄의 진화는?',2,'라이츄|리자몽','c0ead359-3b49-4fe4-a7df-12458ef2f479_피카츄.jfif',20,'choice',27),(565,'5','다음 아바타는 11조 조원 누구의 아바타인가?',6,'남현우|최영선|김지수|최진욱|박무창|강석민','03b38faf-afa6-40e6-aa23-34d1939288e5_박무창.png',30,'choice',27),(573,'1','1',1,'1',NULL,1,'choice',568),(598,'1','다음 아바타는 누구의 아바타일까요?',2,'박무창|김지수','3ad49179-5a82-42dc-bc97-db3121a6ed71_박무창.png',50,'choice',597),(624,'1','피카츄의 진화는?',2,'라이츄|파이리','6476ecee-5fc4-45be-b77a-ac47140049f9_피카츄.jfif',10,'choice',623);
/*!40000 ALTER TABLE `quiz` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 16:06:24
