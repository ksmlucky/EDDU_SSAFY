-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: localhost    Database: ssafy_web_db
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('111111','1234234234@pirate.com',_binary '\0','name1','nickname1','falsePasssword','professor','010-123-123'),('222221','1234234@pirate.com',_binary '\0','name1','nickname1','falsePasssword','professor','010-123-123'),('333331','1234234@pirate.com',_binary '\0','name1','nickname1','falsePasssword','professor','010-123-123'),('444441','1345345@pirate.com',_binary '\0','name1','nickname1','falsePasssword','professor','010-123-123'),('55551','16456456@pirate.com',_binary '\0','name1','nickname1','falsePasssword','professor','010-123-123'),('5675671','5675671@pirate.com',_binary '\0','name1','nickname1','falsePasssword','professor','010-123-123'),('567567561','4564561@pirate.com',_binary '\0','name1','nickname1','falsePasssword','professor','010-123-123'),('5765671','156756@pirate.com',_binary '\0','name1','nickname1','falsePasssword','professor','010-123-123'),('666661','3453451@pirate.com',_binary '\0','name1','nickname1','falsePasssword','professor','010-123-123'),('678678678671','1345@pirate.com',_binary '\0','name1','nickname1','falsePasssword','professor','010-123-123'),('77771','1234234@pirate.com',_binary '\0','name1','nickname1','falsePasssword','professor','010-123-123'),('78978971','1234@pirate.com',_binary '\0','name1','nickname1','falsePasssword','professor','010-123-123'),('9888881','1345345@pirate.com',_binary '\0','name1','nickname1','falsePasssword','professor','010-123-123'),('999991','11213@pirate.com',_binary '\0','name1','nickname1','falsePasssword','professor','010-123-123'),('cheuora','cheuora@gmail.com',_binary '\0','김성준','게부라','$2a$10$dMex0A04EQC/Kor0joTdz.QZ/QBnEKSXWAGu2IZu7Axt7un5Mj4ye','professor','01076821360'),('choi940923','choi940923@gmail.com',_binary '\0','문관희','나의 히어로 아카데미아','$2a$10$3O12YxpibPhzjcNu3vLmqOUXidxhiYL/Tg51LFxRe.gXShVmfeAZ2','professor','01098765432'),('disis','vnddns26@naver.com',_binary '\0','최영선','광주_1반_최영선','$2a$10$q59vbNc.d4w/XKHZRjTAZueYsGbvl.IaeOCH75g9i0Y4QrBf0wj4S','professor','01084430926'),('gkgustj','gkgustj@naver.com',_binary '\0','현서','현서','$2a$10$0lHz8JEZrKdk31.XLcnHfuBz3mbv45zufUt903/0RuDWaZix1iS.y','professor','01011111111'),('kimjs1995','kimjs1995@naver.com',_binary '\0','김지수','kim','$2a$10$wSG8jz9GidbpLgEhpW/94.2/eJgVQ.JgNZduLN.JmGVD6EoiBAfaO','professor','01011112222'),('kimssafy','kiwlt1995@gmail.com',_binary '\0','김싸피','광주_1반_김지수','$2a$10$bhc141HvbP62PUIN0a2qouRumBKQEwnvF1wyfU/.pyMCOD1H80Rju','student','01022221111'),('ksmksm','ksmhero@naver.com',_binary '\0','익명','광주_1반_강석민','$2a$10$QJuTmpmySPZNI0UsgGeV.uRUoTDsXglXVEmaqcsjHjtc9B22dTWJa','student','01012341234'),('skagusdn','frozen_load7@naver.com',_binary '\0','남현우','교수_남현우','$2a$10$qHYHOYX7gCSyEV/vsbiErujLYjjNKpPRjBNKtworx2M1G87li2MJC','professor','01012341234'),('skagusdn2','pika@naver.com',_binary '\0','피카츄','학생_남현우','$2a$10$IbRJhjeW4kOksEh9A3BuH.Wxs8rNHvYPhWAK07BucZv9PqtMSA2/a','student','01012341234'),('ssafy1','sodauschlrdh@naver.com',_binary '\0','박무창','광주_1반_박무창','$2a$10$t4SnT.teuQqn8cB37OTxiukxMEbbGWPqLP.KhTmhBcIQZ7HBO367q','professor','01000000000'),('user1','chlwlsdnr1000@gmail.com',_binary '\0','최진욱','싸피탈주자','$2a$10$I4NhX4Iyqjjb4XPQs5cG2utwSdZ2Gw/4axal8wF4CSrBMV4EEUpJ2','professor','01048112442'),('user5','choi940923@naver.com',_binary '\0','최기현','우리아빠','$2a$10$OXnbFNhbARpDpbG9emFzfO0vgGiBukC0qtKkO3Lxja5Vsok3Owbei','professor','01012345678'),('wlsdnr94','chlwlsdnr1001@gmail.com',_binary '\0','최현석','광주1반_최진욱','$2a$10$cyOLYeypfjlQyHfbTrhjoOeuZrh0aucqRC.jW82WSVxr2McPw4XVC','student','01024424811');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 16:06:19
